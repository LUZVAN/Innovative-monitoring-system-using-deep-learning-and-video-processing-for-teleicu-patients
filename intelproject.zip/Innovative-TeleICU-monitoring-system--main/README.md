Intel Unnati Industrial Training Program 2024 
P.S - Innovative monitoring system for teleICU patient using video processing and deep learning
Team name - AI Aspirers
Team members - 
               1) Tanmay Pranjale(Team Lead)
               2) Shrushti Dixit
               3) Mithilesh Dudhankar
